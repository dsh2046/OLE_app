describe("UI Checkbox", function() {

  moduleTests({
    module  : 'checkbox',
    element : '.ui.checkbox'
  });

});